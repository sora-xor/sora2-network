# SORA 4.8.12 runtime upgrade

Runtime spec **134**, transaction version **131**, preserves the reviewed fee
policy and adds two follow-up fixes. Successful outgoing bridge approvals retain
all declared admission/validation weight. A funded but underpriced migration
sponsor grant can be replaced by an adequate grant for a zero-XOR claimant;
replacement cannot reduce a funded grant's existing limits.

BABE/GRANDPA reports and Kensetsu/Apollo maintenance require funded signed
submission. Successful order cancellation and first useful requested-preimage
provision retain refunds; invalid/replayed cancellation, unauthorized Rewards
calls and requested-preimage replay retain fees. See [FEE_POLICY.md](FEE_POLICY.md).

Registered bridge peers require **zero XOR** for authenticated protocol
operations, including accepted local failures. Invalid/replayed work is rejected
before execution. New bridge proposals have a fair per-proposer quota inside
the shared 128-operation limit. Current peers can cancel orphaned proposals by
quorum at a full queue without the proposer or execution of their payload.
Cleanup preserves incoming state and shared dispatch markers. It does not retry
an already consumed incoming transaction.

Migration sponsorship remains voluntary, claimant-bound and bounded by fee,
budget, expiry and at most three attempts. Failed settlement is paid; success
retains its refund. No automatic sponsor, peer escrow or bridge bond is added.
The preceding VAL staking compatibility repair remains included.

Final Wasm SHA-256: `210511d91f41e406119aa020a32e95864ba95ddd20b860b233231abc06de7d8c` (3,092,259 bytes).
Source overlay tree: `0d8d3623d8dafcf699dad11bb75f5937e8dbb46d`, reapplied to reviewed base
`802298f120edfe6b9c71bec39d2544c58c1391b2`. Fresh native evidence records **1,154 passed**,
zero failures, **3 existing ignores**, and **35**
runtime regressions. All three follow-up regressions are required explicitly.
The previous `faf9ab84...` package and older 430-test evidence are historical
context, not fresh execution. [VALIDATION.md](VALIDATION.md) records the final gates.

The corrected stage/test genesis blobs are separately bound to the same source,
the exact feature profiles and current runtime metadata. Only `:code` changes
from the reviewed 802298f chain specs; all other values and bytes are preserved.
Feature binaries and large feature metadata are not duplicated in the package.
The optional workspace verification checks each actual JSON and embedded blob.

Six unsigned governance review calls are bound to the final Wasm and finalized
preflight block **27,909,600**. Follow [GOVERNANCE-RUNBOOK.md](GOVERNANCE-RUNBOOK.md)
after verifying the ZIP companion hash and extracted `SHA256SUMS`. The guarded
route preserves an occupied external queue; it does not supersede another
proposal. Refresh the deployed baseline/preflight before activation, and repeat
compatibility and Wasm checks if that baseline changes.

Preparation does not install/fund operator keys, attest rollout, sign or submit
a governance transaction, or enact code. All report-generated fingerprints in
this document must be finalized before the package can pass verification.

Fresh feature-runtime regeneration gate: **passed**.
Fresh three-profile Clippy gate: **passed**.
