# SORA 4.8.12 follow-up validation

Candidate SHA-256: `210511d91f41e406119aa020a32e95864ba95ddd20b860b233231abc06de7d8c` (3,092,259 bytes).
Source tree: `0d8d3623d8dafcf699dad11bb75f5937e8dbb46d`; reviewed base: `802298f120edfe6b9c71bec39d2544c58c1391b2`.
Fresh evidence records **1,154 passed**, zero failed,
**3 existing ignored** tests across eleven affected native suites.
**35** runtime regressions and all three named follow-up
regressions passed. The predecessor's 1,151-test/32-regression results and source
`2fe0bf...` remain historical context in `validation/predecessor-context.json`.
The older 430 maintenance/common/inbound results retain their original logs and
source provenance in `validation/historical-owned-tests-context.json`.

## Source and fresh local checks

`source.patch` reconstructs the recorded runtime compilation source overlay
from base 802298f. `capture-source.py` hashes changed files plus both manifests
and lockfiles, the bridge/migration production code, runtime sponsorship helper,
and regression files. Generated chain-spec blobs are separately bound because
they are produced after the feature builds. No clean-commit build is claimed.

`record-build-evidence.py` binds original native/format/mainnet-build log bytes
and locked Wasm dependency packages. It requires these successful real-signature
Executive regressions by exact name:

- `outgoing_approval_retains_validation_weight_before_and_at_quorum`
- `funded_underpriced_grant_can_be_replaced_without_claimant_xor`
- `replacement_cannot_reduce_a_funded_grants_limits`

These cover the two new behavior changes. Existing report-fee, cancellation,
Rewards, requested-preimage, keeper, sponsorship and bridge-capacity suites remain
mandatory. `record-clippy-evidence.py` separately binds fresh mainnet, try-runtime
and extended Clippy logs without rereading Wasm output overwritten by later
feature builds. Neither recorder rewrites a log's contents.

## Exact mainnet Wasm checks

The pinned public snapshot supplies deployed code, metadata and state. Local
Chopsticks replaces only the runtime code, executes upgrade initialization and
a timestamp, and checks staking claims/ledgers and native XOR issuance. Report
rehearsal covers all four signed/legacy report methods, paid duplicate failures,
paid wrappers, bare admission/application rejection and disabled unsigned
submission APIs. An independent event check matches actual charges to balances.

The broader fee rehearsal requires useful cancellation/refund and paid replay,
charged empty/no-op cancellation shapes, unauthorized Rewards, requested-preimage
first/replay, signed invalid maintenance, bare maintenance rejection, and invalid
inbound proof rejection. Existing fresh authenticated bare bridge submissions
remain supported. Synthetic zero-XOR legacy peer and capacity cases cover
accepted failures, consumed state, 32/33 quota fairness, honest admission,
full-queue orphan cleanup, current quorum, absence of payload execution,
preserved canonical state and foreign dispatch markers, rejected stale/duplicate
votes and reuse of capacity. Every local key/value override is disclosed. The
capacity cases isolate and record block weight/size accounting; they do not claim
that all fixture transactions fit one block.

Final fee-policy counts: **54 signed** cases
(**12 paid**, **42 free**), with all balance/fee/nonce
assertions passing. Report signatures and headers use the mock signature host;
native tests separately cover real cryptography. No transaction is submitted.
These fixtures prove candidate behavior, not execution of a live bridge request.
New bridge-weight/sponsor-replacement behavior is covered by the named native
regressions; it is not mislabeled as a new exact-Wasm fixture.

## Compatibility and regenerated chain specs

The deployed-baseline comparator preserves existing SCALE shapes, indices,
storage, signed extensions and runtime APIs. A separate predecessor comparison
uses sealed `faf9ab84f3087639c4913ada9e17ea055fffc913b936b3c366fa2791ccd5ea59`
and requires **no ABI or constant additions/changes**. Existing call 18 and all
three capacity storage items must remain present. Historical comparison with the
original pre-capacity 4.8.12 candidate is retained separately and never replaces
this new check. Host imports/signatures/exports and memory compatibility retain
all preceding gates and stated executor limitations.

`validation/refresh-chain-specs.py` runs offline. Its report binds the source
provenance, helper/comparator bytes, feature Wasm hashes and all three JSONs.
Stage and bridge staging use `build-wasm-binary,private-net,stage`; test also uses
`wip,reduced-pswap-reward-periods`. None uses `runtime/test`. Both variants must
advertise 134/131, include private-network Sudo, call 18 and all three capacity
storage items, and preserve old pallet indices/SCALE encodings. The helper
replaces only `:code`, preserving all remaining JSON values/bytes and the existing
LastRuntimeUpgrade value. No feature Wasm or large metadata is duplicated in ZIP;
`verify-package.py --check-workspace-source` additionally hashes each real JSON
and its embedded code against the report.

The bounded bridge-readiness report remains an inspection with incomplete scan
coverage, not operator attestation. Registered peers need no XOR. Admission caps
and call-size bounds remain in effect; quorum cleanup needs no stored call bytes.
Weight multipliers/allowances are conservative engineering estimates over old
benchmarks, not newly measured worst-case throughput.

## Governance and final integrity gate

Fresh finalized preflight block: **27,909,600**.
Final setCode proposal: `0x42b0bb28bb2d5e6f8107ec48ed6cf0bca3db1d8620a350fae550b6889d4fe9ed` (3,092,265 bytes).
Offline governance verification decodes all six review calls against the checked
baseline metadata and matches them to the final Wasm and guarded council settings.
An occupied external queue is preserved; this package does not enact or supersede
another proposal. Refresh the preflight and repeat baseline-sensitive checks
before governance use.

The manifest verifier binds every distributable file, current scripts/reports,
exact Wasm, source overlay, native/lint/build evidence, predecessor metadata,
chain-spec report, governance payloads and original logs. It rejects placeholders
in README/VALIDATION, stale source trees, missing new regressions and mismatched
fingerprints. Final documentation is generated from passed reports by
`validation/finalize-docs.py`; no former success totals are carried forward as
fresh results. Operator key installation/funding, relayer readiness, production
consensus authoring and governance enactment remain outside local evidence.

Fresh feature-runtime regeneration gate: **passed**.
Fresh three-profile Clippy gate: **passed**.
