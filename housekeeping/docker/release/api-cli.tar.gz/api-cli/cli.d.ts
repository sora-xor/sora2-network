interface ArgV {
    [argName: string]: unknown;
    _: string[];
    $0: string;
}
export declare function hexMiddleware(argv: ArgV): ArgV;
export declare function jsonMiddleware(argv: ArgV): ArgV;
export declare function parseParams(inline: string[], file?: string): string[];
export {};
