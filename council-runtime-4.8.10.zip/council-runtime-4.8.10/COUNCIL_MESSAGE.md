Subject: Council review of SORA mainnet runtime 4.8.10

Council members,

Please review the attached SORA mainnet runtime 4.8.10 upgrade. The current
runtime advertises BABE secondary-VRF slots while finalized canonical blocks use
secondary-plain slots. That mismatch can leave affected validators unable to
import blocks or author, even after they come back online. The upgrade makes the
BABE configuration API report the active epoch correctly and schedules Plain
through BABE's normal epoch transition. It advances runtime spec version 131 to
132; transaction version stays at 131.

The exact candidate is `framenode-runtime-4.8.10.compact.compressed.wasm`
(3,055,007 bytes; SHA-256
`a39de37798885ee253db508c553aca80321974fdd20fa0830bb94220cb9224c3`).
Its encoded `System.set_code` call is 3,055,013 bytes, with preimage hash
`0xcb822d1ad3293838ba0ecfb4eb9ded109c040693f626e406f07b184ecc5e6713`.
Please use the full encoded call as the preimage, not the raw Wasm. The source,
tests, and validation record are in
https://github.com/sora-xor/sora2-network/pull/1366 and the attached
`VALIDATION.md`.

The read-only mainnet check at finalized block 27,748,140 on 23 September 2026
still showed spec 131, the expected deployed runtime, current and next BABE
configs set to VRF with `c=(1,4)`, no pending BABE configuration change, and
recent canonical Plain blocks. However, `Democracy.NextExternal` already held a
different proposal (hash
`0x3eaa14c5845c5de1234d7e8eea51ea0f7a9186803fe792028001d8bf8db1aa2c`,
length 3,036,855). A Council `external_propose_majority` call would replace that
entry. Please decide how to handle the existing proposal and repeat the live
checks before opening this upgrade motion.

Council approval starts the governance process; it does not enact the runtime
by itself. Any Technical Committee fast-track and public referendum are separate
steps. After enactment, the first epoch boundary announces Plain and the second
makes it active, normally about one to two hours later. Affected nodes with an
incompatible local BABE cache may still need the documented offline repair or a
fresh synchronization. No governance call in this bundle has been signed or
submitted.
